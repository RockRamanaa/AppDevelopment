# spring-boot-registration-login
Sample Project demonstrating User Registration and Login with Spring Boot
### Follow our written tutorial here: [Spring Boot Registration and Login with MySQL Database Tutorial](https://www.codejava.net/frameworks/spring-boot/user-registration-and-login-tutorial)
### Follow our video tutorial here: [Spring Boot Registration and Login with MySQL Database, Bootstrap and HTML5](https://www.youtube.com/watch?v=aRLoSDOlU3w)
